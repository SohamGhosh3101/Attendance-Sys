#include <stdio.h>

void main ( )

{
    int x = 6 ;
    int y = 4 ;
    x = x + y ;
    printf("%d", x);
}