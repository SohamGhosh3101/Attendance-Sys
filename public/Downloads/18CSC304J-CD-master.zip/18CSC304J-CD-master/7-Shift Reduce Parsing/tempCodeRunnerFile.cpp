	char p2[10];
